package mybatis.day21.dao;

import mybatis.day21.pojo.Role;

import java.util.List;

public interface RoleMapper {

    /**
     * 查找所有Role信息
     * @return
     */
    List<Role> findAllRole();

    /**
     * 根据ID查找Role信息
     * @return
     */
    Role findRoleById(int id);

    int insertRole(Role role);

    int updateRole(Role role);

    int DeleteRoleById(int id);


}
