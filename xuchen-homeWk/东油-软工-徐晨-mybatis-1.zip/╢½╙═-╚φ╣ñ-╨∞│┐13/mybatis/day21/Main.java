package mybatis.day21;

import mybatis.day21.dao.RoleMapper;
import mybatis.day21.pojo.Role;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * @Author Xuchen
 * @Date 2019/8/8 10:31
 * @Version 1.0
 * MapperRegistry由mybatis提供，错误是对rolemapper接口存在不识别
 * RoleMapper.xml已配置namespace过，为什么还报错？
 * 没有代码加载配置过RoleMapper.xml，所以找不到。
 */
public class Main {

    private static final Logger LOGGER = Logger.getLogger(Main.class);
    private static final boolean IS_OUTPUT_LOGGER = true;

    public static void main(String[] args) {
        SqlSession sqlSession = null;

        try {
            SqlSessionFactoryUtil.createFactory();
            sqlSession = SqlSessionFactoryUtil.getSqlSeesion();
            RoleMapper roleMapper = sqlSession.getMapper(RoleMapper.class);
//            List<Role> roleList = roleMapper.findAllRole();
//
//
//            if (null != roleList){
//                roleList.forEach(System.out::println);
//            }
            Role role = roleMapper.findRoleById(1);
            //System.out.println(role.toString());

            if (IS_OUTPUT_LOGGER) {
                LOGGER.error(role);
            }

            Role role1 = new Role();
            role1.setNote("good!!!!!!");
            role1.setRolename("rrrrr");
            int count = roleMapper.insertRole(role1);
            sqlSession.commit();
            LOGGER.debug(count+" ");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != sqlSession) {
                sqlSession.close();
            }
        }


    }
}
