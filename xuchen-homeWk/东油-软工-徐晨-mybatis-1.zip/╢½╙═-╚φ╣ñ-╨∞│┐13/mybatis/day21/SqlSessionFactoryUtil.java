package mybatis.day21;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.concurrent.locks.Lock;

/**
 * @Author Xuchen
 * @Date 2019/8/8 10:17
 * @Version 1.0
 */
public class SqlSessionFactoryUtil {

    private static final Class<SqlSessionFactoryUtil> LOCK = SqlSessionFactoryUtil.class;

    /**
     * SqlSeesion工厂类变量，单类
     */
    static SqlSessionFactory sqlSessionFactory = null;

    private static void initFactory() {

        if (null == sqlSessionFactory) {
            createFactory();
        }
    }

    public static void createFactory() {
        synchronized (LOCK) {
            if (null == sqlSessionFactory) {
                String path = "src/batis-config.xml";
                InputStream inputStream = null;
                try {
                    inputStream = new FileInputStream(path);

                    //从calsspath位置开始读取对应path文件
                    sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    //sqlSessionFactory ->SqlSession(Connection)
    public static SqlSession getSqlSeesion() {
        return sqlSessionFactory.openSession();
    }


}
