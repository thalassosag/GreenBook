package jdbcDemo.demo.homework.work1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jdbcDemo.demo.jdbcutil;

/**
 * @Author Xuchen
 * @Date 2019/8/6 16:17
 * @Version 1.0
 */
public class BusinessDemo {


    public static void main(String[] args) {
        try {
            saveOrder();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }







    public static void saveOrder() throws IOException, SQLException {

        Connection connection = jdbcutil.getCon();
        PreparedStatement preparedStatement = null;
        // 默认情况下，自动提交是开启的，1-DDL,DCL 2-程序运行结束
        // 关闭自动提交功能，设置为false，
        // 需要手动调用commit来提交，将修改持久化到数据库
        connection.setAutoCommit(false);

        //第一个修改操作
        String sql = "insert into gorder values(null,1,9)";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();

        //第二个修改操作
        String sql1 = "update sto set gcout = gcout-5 where gid=1";
        preparedStatement = connection.prepareStatement(sql1);
        preparedStatement.executeUpdate();

        connection.commit();

        jdbcutil.closeResource(preparedStatement);
        jdbcutil.closeResource(connection);

    }

}
