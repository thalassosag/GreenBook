package jdbcDemo.demo.homework.work2;

import jdbcDemo.demo.jdbcutil;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @Author Xuchen
 * @Date 2019/8/6 18:15
 * @Version 1.0
 *
 * 1.自己设计场景，完成一个事务练习
 *
 * 2.根据昨天练习的表，完成名称或其他字段模糊查找
 *
 * ​                  方法名，如：findByUserNameLike(String userName)
 *
 * 3.根据昨天练习的表，完成根据某个字段进行排序（降序）的操作
 *
 * ​                 方法名，如：findOrderByUserName()
 *
 * 4.根据昨天练习的表，完成根据某个字段模糊查找并排序（升序），然后分页获取第二页数据的操作（每页显示2条）
 *
 * ​                方法名，如：findByUserNameLikeOrderLimit(String userName，int currPage, int pageSize)
 *
 * userName:用户名
 *
 * currPage:当前页
 *
 * pageSize:每页显示的数量
 *
 * **提交方式**
 *
 * 1. 正常提交到班级服务器
 * 2. 提交到昨天的创建的git项目目录下，将提交内容放到一个新文件夹中
 */
public class FindIndistinct {
    public static void main(String[] args) {
        try {
            findBySdeptIndistinct("C");
            findOrderBySnoDESC();
            findByNameLikeOrderLimit("C",2,2);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 对sdept进行模糊查询
     * @param sdept
     * @return
     * @throws IOException
     * @throws SQLException
     */
    public static ResultSet findBySdeptIndistinct(String sdept) throws IOException, SQLException {

        //获取连接对象
        Connection connection = jdbcutil.getCon();
        PreparedStatement preparedStatement = null;

        //sql语句拼接
        StringBuffer sql = new StringBuffer();
        sql.append("select * from student where sdept like ?");
        preparedStatement = connection.prepareStatement(sql.toString()) ;
        preparedStatement.setString(1, "%"+sdept+"%");
        //执行查询
        ResultSet resultSet =  preparedStatement.executeQuery();

        //遍历查询结果
        Student student = null;
        while (resultSet.next()){
            student = new Student();
            student.setSno(resultSet.getString(1));
            student.setSname(resultSet.getString(2));
            student.setSsex(resultSet.getString(3));
            student.setSage(resultSet.getInt(4));
            student.setSdept(resultSet.getString(5));
            System.out.println(student.toString());
        }


        return null;
    }

    /**
     * 按照sno的降序查询所有信息
     * @throws IOException
     * @throws SQLException
     */
    public static void findOrderBySnoDESC() throws IOException, SQLException {
        //获取连接对象
        Connection connection = jdbcutil.getCon();
        PreparedStatement preparedStatement = null;

        //sql语句拼接
        StringBuffer sql = new StringBuffer();
        sql.append("select * from student order by sno desc");
        preparedStatement = connection.prepareStatement(sql.toString()) ;

        //执行查询
        ResultSet resultSet =  preparedStatement.executeQuery();

        //遍历查询结果
        Student student = null;
        while (resultSet.next()){
            student = new Student();
            student.setSno(resultSet.getString(1));
            student.setSname(resultSet.getString(2));
            student.setSsex(resultSet.getString(3));
            student.setSage(resultSet.getInt(4));
            student.setSdept(resultSet.getString(5));
            System.out.println(student.toString());
        }



    }

    /**
     * 按照sno的降序并对sdept模糊查询的信息，分页并显示第二页。每页两条
     * @param sdept
     * @param currPage
     * @param pageSize
     * @throws IOException
     * @throws SQLException
     */
    public static void findByNameLikeOrderLimit(String sdept,int currPage,int pageSize) throws IOException, SQLException {
        //userName:用户名
        //currPage:当前页
        //pageSize:每页显示的数量

        //获取连接对象
        Connection connection = jdbcutil.getCon();
        PreparedStatement preparedStatement = null;

        //sql语句拼接
        StringBuffer sql = new StringBuffer();
        sql.append("select * from student where sdept like ? order by sno desc");
        preparedStatement = connection.prepareStatement(sql.toString()) ;
        preparedStatement.setString(1, "%"+sdept+"%");

        //执行查询
        ResultSet resultSet =  preparedStatement.executeQuery();

        //遍历查询结果
        Student student = null;
        //用list接受
        Collection<Student> students = new ArrayList<>();
        while (resultSet.next()){
            student = new Student();
            student.setSno(resultSet.getString(1));
            student.setSname(resultSet.getString(2));
            student.setSsex(resultSet.getString(3));
            student.setSage(resultSet.getInt(4));
            student.setSdept(resultSet.getString(5));
            students.add(student);
        }
        //对list进行遍历，寻找需要的结果
        for (int i = (currPage-1)*pageSize; i < pageSize; i++) {
            System.out.println(((ArrayList<Student>) students).get(i).toString());
        }

    }


}
