package com.classwork.day18.homework1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 产生一个报告，报告中有得到的数值，根据报告中的数值，给与不同的品牌推荐
 */

public class Main {
    public static void main(String[] args) throws IOException{
        reportRecommend();
    }

    public static void reportRecommend() throws IOException{
        Connection connection = JDBCUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            connection.setAutoCommit(false);
            //插入报告信息，values（ID,Name,score）
            String sql="insert into report values(15489798,王鹏,80)";
            //recommend.min   该推荐适用最小分值
            //recommend.max   该推荐适用最大分值
            String sql1="select recommend from recommend where recommend.min<80 and recommend.max>80";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate();
            preparedStatement=connection.prepareStatement(sql1);
            preparedStatement.executeQuery();
            connection.commit();

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        }finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            JDBCUtil.closeConnection(preparedStatement);
            JDBCUtil.closeConnection(connection);
        }


    }
}

