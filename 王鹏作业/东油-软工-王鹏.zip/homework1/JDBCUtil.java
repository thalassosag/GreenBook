package com.classwork.day18.homework1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JDBCUtil {


    public static Connection getConnection() throws IOException {
        /**
         * 运用properties
         */
        Properties properties = new Properties();
        //jdbc驱动
        String filepath = JDBCUtil.class.getResource("/").toString() + "jdbc.properties";
        InputStream inputStream = new FileInputStream(filepath);
        properties.load(inputStream);
        try {
            Class.forName(properties.get("driver").toString());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Connection connection = null;
        try {
            //详细信息
            connection = DriverManager.getConnection(properties.get("url").toString(), properties.get("username").toString(), properties.get("passwd").toString());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return connection;
    }
    public static void closeConnection(AutoCloseable autoCloseable) {
        if (null != autoCloseable) {
            try {
                autoCloseable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
