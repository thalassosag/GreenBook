package com.classwork.day18.homework2;

import com.classwork.day18.homework1.JDBCUtil;
import com.sun.org.apache.bcel.internal.generic.NEW;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 2.根据昨天练习的表，完成名称或其他字段模糊查找
 *
 * ​                  方法名，如：findByUserNameLike(String userName)
 *
 * 3.根据昨天练习的表，完成根据某个字段进行排序（降序）的操作
 *
 * ​                 方法名，如：f
 *
 * 4.根据昨天练习的表，完成根据某个字段模糊查找并排序（升序），然后分页获取第二页数据的操作（每页显示2条）
 *
 * ​                方法名，如：findByUserNameLikeOrderLimit(String userName，int currPage, int pageSize)
 *
 * userName:用户名
 *
 * currPage:当前页
 *
 * pageSize:每页显示的数量
 *
 * **提交方式**
 *
 * 1. 正常提交到班级服务器
 * 2. 提交到昨天的创建的git项目目录下，将提交内容放到一个新文件夹中
 */
public class Find {
    public static void main(String[] args) throws IOException, SQLException {
        Scanner scanner = new Scanner(System.in);
        Demo demo = new Demo();
        demo.setUsername(scanner.nextLine());
        demo.setPassword(scanner.nextLine());
        demo.setID(scanner.nextLine());
        String userName = scanner.nextLine();
        int currPage = 2;
        int pageSize = scanner.nextInt();
        findByUserNameLike(demo.getUsername());
        findOrderByUserName();
        findByUserNameLikeOrderLimit(userName, currPage, pageSize);
    }

    public static void findByUserNameLike(String userName) throws IOException, SQLException {
        Connection connection = JDBCUtil.getConnection();
        ResultSet resultSet = null;
        Statement statement = connection.createStatement();
        String sql1 = "SELECT * FROM TABLE1 WHERE USERNAME LIKE '" + userName + "%'";
        resultSet = statement.executeQuery(sql1);
        List<Demo> demos = new ArrayList<>();
        while (resultSet.next()) {
            String username = resultSet.getString("username");
            String password = resultSet.getString("password");
            String ID = resultSet.getString("ID");
            Demo demo1 = new Demo();
            demo1.setID(ID);
            demo1.setPassword(password);
            demo1.setUsername(username);
            demos.add(demo1);
        }
        for(Demo demo2:demos){
            System.out.println(demo2.toString());
        }


    }

    public static void findOrderByUserName() throws IOException, SQLException {
        Connection connection = JDBCUtil.getConnection();

        Statement statement = connection.createStatement();
        String sql1 = "SELECT * FROM TABLE1 WHERE ORDER BY USERNAME";
        ResultSet resultSet1 = statement.executeQuery(sql1);
        List<Demo> demoList = new ArrayList<>();
        while(resultSet1.next()){
            String username = resultSet1.getString(1);
            String password = resultSet1.getString(2);
            String ID = resultSet1.getString(3);
            Demo demoObject = new Demo();
            demoObject.setID(ID);
            demoObject.setPassword(password);
            demoObject.setUsername(username);
            demoList.add(demoObject);
        }
        for(Demo demo2:demoList){
            System.out.println(demo2.toString());
        }

    }

    public static void findByUserNameLikeOrderLimit(String userName, int currPage, int pageSize) throws IOException, SQLException {
        Connection connection = JDBCUtil.getConnection();
        ResultSet resultSet = null;
        Statement statement = connection.createStatement();
        String sql1 = "SELECT * FROM TABLE1 WHERE USERNAME LIKE '" + userName + "%' AND ORDER BY USERNAME";
        //分页对应数据为currPage*pagesize-2,currPage*2-1
        resultSet = statement.executeQuery(sql1);
        List<Demo> demoList = new ArrayList<>();
        while (resultSet.next()) {
            String username = resultSet.getString("username");
            String password = resultSet.getString("password");
            String ID = resultSet.getString("ID");
            Demo demo1 = new Demo();
            demo1.setID(ID);
            demo1.setPassword(password);
            demo1.setUsername(username);
            demoList.add(demo1);
        }
        boolean isrunning = true;
        while (isrunning) {
            int count = 0;
            if (currPage != -1 && pageSize > 0) {
                count = pageSize;
                int fromIndex = currPage * pageSize;
                int toIndex = (currPage + 1) * pageSize;
                if (toIndex > count) {
                    toIndex = count;
                }

            }


        }
    }

}
