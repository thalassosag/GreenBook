package com.homeWork.day17;

import java.util.List;

public interface Operatable {
    List<Operation> operationQuery();//查询
    int operationUpdate(Operation operation);//更新
    int operationInsert(Operation operation);//添加
    int operationDeleteByID(String id);//删除
}
