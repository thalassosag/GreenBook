package com.homeWork.day17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ServerConnection {
    private ServerConnection() {
    }

    private static ServerConnection serverConnection = null;

    public static ServerConnection getInstance() {
        if (null == serverConnection) {
            serverConnection = new ServerConnection();
        }
        return serverConnection;
    }

    public Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/operation", "root", "123456");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  connection;

    }
    public void closeConnection(AutoCloseable autoCloseable){
        if(null != autoCloseable){
            try {
                autoCloseable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
