package com.homeWork.day17;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class operator implements Operatable {
    public List<Operation> operationQuery() {
        Connection connection = ServerConnection.getInstance().getConnection();
        Statement statement = null;
        ResultSet rs = null;
        List<Operation> list = new ArrayList<>();

        try {
            statement = connection.createStatement();
            String sql ="select * from student";
            rs = statement.executeQuery(sql);

            while(rs.next()){
                String id  = rs.getString(1);
                String name = rs.getString(2);
                String sex = rs.getString(3);
                int lesson = rs.getInt(4);

                Operation operation = new Operation();
                operation.setSno(id);
                operation.setSname(name);
                operation.setSsex(sex);
                operation.setLesson(lesson);
                list.add(operation);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            ServerConnection.getInstance().closeConnection(rs);
            ServerConnection.getInstance().closeConnection(statement);
            ServerConnection.getInstance().closeConnection(connection);

        }
        return list;
    }

    @Override
    public int operationUpdate(Operation operation) {
        Connection connection = ServerConnection.getInstance().getConnection();
        Statement statement = null;

        try {
            statement = connection.createStatement();
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("update student set Sname='");
            stringBuffer.append(operation.getSname());
            stringBuffer.append("', Ssex='");
            stringBuffer.append(operation.getSsex());
            stringBuffer.append("', Lesson=");
            stringBuffer.append(operation.getLesson());
            stringBuffer.append(" where Sno='");
            stringBuffer.append(operation.getSno());
            stringBuffer.append("'");

            System.out.println(stringBuffer.toString());

            int affectedRows = statement.executeUpdate(stringBuffer.toString());

            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            ServerConnection.getInstance().closeConnection(statement);
            ServerConnection.getInstance().closeConnection(connection);
        }
        return 0;
    }

    @Override
    public int operationInsert(Operation operation) {
        Connection connection = ServerConnection.getInstance().getConnection();
        Statement statement = null;

        try {
            statement = connection.createStatement();
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("insert into student values(");
            stringBuffer.append("'");
            stringBuffer.append(operation.getSno());
            stringBuffer.append("','");
            stringBuffer.append(operation.getSname());
            stringBuffer.append("','");
            stringBuffer.append(operation.getSsex());
            stringBuffer.append("','");
            stringBuffer.append(operation.getLesson());
            stringBuffer.append("')");

            System.out.println(stringBuffer.toString());

            int affectedRows = statement.executeUpdate(stringBuffer.toString());

            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            ServerConnection.getInstance().closeConnection(statement);
            ServerConnection.getInstance().closeConnection(connection);
        }

        return 0;
    }

    @Override
    public int operationDeleteByID(String id) {
        Connection connection = ServerConnection.getInstance().getConnection();
        Statement statement = null;

        try {
            statement = connection.createStatement();
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("delete from student where Sno='");
            stringBuffer.append(id);
            stringBuffer.append("'");

            System.out.println(stringBuffer.toString());

            int affectedRows = statement.executeUpdate(stringBuffer.toString());

            return affectedRows;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            ServerConnection.getInstance().closeConnection(statement);
            ServerConnection.getInstance().closeConnection(connection);
        }
        return 0;
    }
}
